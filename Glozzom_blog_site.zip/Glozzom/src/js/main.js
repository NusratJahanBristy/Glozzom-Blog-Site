$('.slider').slick({
	infinite: true,
	slideToShow: 1,
	slideToScroll: 1
	});
